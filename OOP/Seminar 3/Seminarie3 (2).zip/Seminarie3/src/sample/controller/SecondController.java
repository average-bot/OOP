package sample.controller;

import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ListView;
import javafx.stage.Stage;
import sample.model.Data;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class SecondController implements Initializable {

    @FXML
    ListView emailListView;

    @FXML public void handleButtonRemove(){
        String selected = (String) emailListView.getSelectionModel().getSelectedItem();
        Data data = Data.getInstance();
        data.removeEmail(selected);
    }

    @FXML public void handleButtonBack(ActionEvent event) throws IOException {
        Parent p = FXMLLoader.load(getClass().getResource("../view/firstScene.fxml"));
        Scene newScene = new Scene(p);
        Stage stage= (Stage)((Node)event.getSource()).getScene().getWindow();
        stage.setScene(newScene);
        stage.show();
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        ObservableList<String> emails = Data.getInstance().getEmails();
        emailListView.setItems(emails);
    }
}
