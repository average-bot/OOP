package sample.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import sample.model.Data;

import java.io.IOException;

public class FirstController {

    @FXML
    TextField registerTextField;

    @FXML public void handleButtonRegister(){
        Data data = Data.getInstance();
        data.setEmail(registerTextField.getText());
        registerTextField.setText("");
    }

    @FXML public void handleButtonShowAll(ActionEvent event) throws IOException {
        Parent p = FXMLLoader.load(getClass().getResource("../view/secondScene.fxml"));
        Scene newScene = new Scene(p);
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        stage.setScene(newScene);
        stage.show();
    }
}
