package sample.model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class Data {
    private ObservableList<String> emails;

    //Create an object of the same class
    private static Data data;

    public static Data getInstance(){
        if(data == null){ //If no object is created
            data = new Data();
        }
        return data;
    }

    public void setEmail(String email) {
        if(email != "") {
            this.emails.add(email);
        }
    }

    public ObservableList<String> getEmails() {
        return emails;
    }

    public void removeEmail(String email){
        this.emails.remove(email);
    }

    //Singelton
    //Only one object can be created with a private constructor
    private Data(){
        emails = FXCollections.<String>observableArrayList();
    }
}
